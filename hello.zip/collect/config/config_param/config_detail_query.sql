select g.*
from config_detail g
where g.group_id ={{.group_name}}