select count(1) as count
from (require('./base.sql')) a