package collect

/**
* 定义一个空结构体，所有插件的方法，基于Plugin 进行添加
**/
type PluginLoader struct {
}
