package collect

import utils "github.com/SelfDown/collect/src/collect/utils"

func CurrentDateFormat(fmt string) string {
	return utils.CurrentDateFormat(fmt)
}
