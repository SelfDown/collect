package collect

import utils "github.com/SelfDown/collect/src/collect/utils"

func CurrentDateTime() string {
	return utils.CurrentDateTime()
}
