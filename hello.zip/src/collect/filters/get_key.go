package collect

import (
	utils "github.com/SelfDown/collect/src/collect/utils"
)

func GetKey(key string) string {
	return utils.GetAppKey(key)
}
