package collect

// Item name的名称
const ItemName = "item"
const RightName = "right"
