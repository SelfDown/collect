package test

import "testing"

func Test2(t *testing.T) {
	// linux 能用，window 不支持
	// 	p, err := plugin.Open("plugin.so")
	// if err != nil {
	// 	fmt.Println(err)
	// }
	// t, err := p.Lookup("SayHelloPlugin")
	// if err != nil {
	// 	fmt.Println(err)
	// }
	// if sayHello, ok := t.(CustomPlugin); ok {
	// 	log.Println(sayHello.CallMe("test"))
	// }

}
